/* CoreAnimation - CoreAnimation.h

   Copyright (c) 2006-2007 Apple Inc.
   All rights reserved. */

#ifndef COREANIMATION_H
#define COREANIMATION_H

#include <QuartzCore/CABase.h>
#include <QuartzCore/CATransform3D.h>

#endif /* COREANIMATION_H */
