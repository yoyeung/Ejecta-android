/*
 * Copyright (c) 2007 Apple Inc.
 * All rights reserved.
 *
 */

#pragma once

#include <CoreGraphics/CoreGraphics.h>
#include <ColorSync/ColorSync.h>
#include <ImageIO/ImageIO.h>
