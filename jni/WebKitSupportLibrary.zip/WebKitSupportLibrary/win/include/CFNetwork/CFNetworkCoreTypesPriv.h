/*
 *  CFNetworkCoreTypesPriv.h
 *  CFNetwork
 *
 *  Copyright 2011 Apple Inc. All rights reserved.
 *
 */

#ifndef __CFNETWORKCORETYPESPRIV__
#define __CFNETWORKCORETYPESPRIV__

#ifndef __CFNETWORKCORETYPES__
#include <CFNetwork/CFNetworkCoreTypes.h>
#endif

#endif		// __CFNETWORKCORETYPESPRIV__

