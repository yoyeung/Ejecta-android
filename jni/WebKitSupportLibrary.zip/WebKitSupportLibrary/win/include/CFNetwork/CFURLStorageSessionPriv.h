/*
 *  CFURLStorageSessionPriv.h
 *  CFNetwork
 *
 *  Copyright 2011 Apple Inc. All rights reserved.
 *
 */

#ifndef __CFURLSTORAGESESSIONPRIV__
#define __CFURLSTORAGESESSIONPRIV__

#ifndef __CFURLSTORAGESESSION__
#include <CFNetwork/CFURLStorageSession.h>
#endif

#endif /* __CFURLSTORAGESESSIONPRIV__ */

