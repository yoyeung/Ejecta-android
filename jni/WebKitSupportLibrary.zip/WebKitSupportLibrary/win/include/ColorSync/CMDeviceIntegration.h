/*
 * ColorSync- CMDeviceIntegration.h
 * Copyright (c)  2008 Apple Inc.
 * All rights reserved.
 */

#pragma warning This file will be removed in future build Please include <ColorSync/ColorSyncDeprecated.h> instead

#include <ColorSync/ColorSyncDeprecated.h>



